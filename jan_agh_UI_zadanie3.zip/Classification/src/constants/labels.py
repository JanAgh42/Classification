RED_X = 'red_point_coords_x'
RED_Y = 'red_point_coords_y'

BLUE_X = 'blue_point_coords_x'
BLUE_Y = 'blue_point_coords_y'

GREEN_X = 'green_point_coords_x'
GREEN_Y = 'green_point_coords_y'

PURPLE_X = 'purple_point_coords_x'
PURPLE_Y = 'purple_point_coords_y'